# Usage
## [server]
### 0.インストール
ngrokのインストール \
https://ngrok.com/

poetryでのパッケージインストール 
```
poetry install
または
poetry install --without client
```


### 1.　ngrokを起動してトンネルを作成
ポート番号は任意. (以下ではRTMPの1935万としているが、他の番号でも良い.)
```
ngrok tcp 1935

ngrok tcp 1935  --log=stdout --log-level=debug
```
画面のForwardingの行を見ると、どのポートが1935番ポートにフォワーディングされるのかがわかる。 \
以下の例だと、 19926番ポートが外部からアクセス可能なポート番号になる. \
(例： `Forwarding tcp://0.tcp.jp.ngrok.io:19926 -> localhost:1935`) \
(`&`つけてバックグラウンドで実行しても良いが、ポート番号見るのにもう1段階踏むのが面倒)


## 2. PythonでSocket通信を開始する
1に合わせ、1935番ポートでPythonでSocket通信を開始する (args.portで設定)
```
poetry run server/python main.py
```


## [client]
### 0.インストール
poetryでのパッケージインストール  \
serverサイドのパッケージを GPUの無いクライアントマシンでインストールするとエラーが起きるかもしれない。

`--without server` をつけてインストールするのはほぼマスト.
```
poetry install --without server
```


## 2. ローカルから音声を送信 (Socket通信)
先のngrokコマンドで公開されたホスト/ポートに, ローカルから音声をTCP通信でストリーミングで送る。


### 2.1. Socket通信 (推奨)
pythonからSocket通信を開始する。

host, portは, server.1で得られたngrokの公開ホスト/ポートに適宜変える. (以下の例では上記に併せて 19926 番ポートを用いる.)
```
poetry run python client/main.py  \
    --host 0.tcp.jp.ngrok.io  \
    --port 19926  \
    --source file  \
    --audio_file wavs/full.wav
```

### 2.2. sox + pv + netcat (for 簡易テスト)
簡単に音声を送信するためのコマンド.\
server.1の例では外部アクセスのためのポートが19926番だったので、コマンドは以下のようになる.\
サンプリングレート16000Hzは、`common.py`の `SAMPLING_RATE`に合わせる。

```
# 以下 Mac
[音声ファイルから]
sox full.wav -e signed -b 16 -c 1 -r 16000 -t raw - | pv -L 32000 | nc 0.tcp.jp.ngrok.io 19926

[マイクから]
sox -d -e signed -b 16 -c 1 -r 16000 -t raw - | nc 0.tcp.jp.ngrok.io 19926
```
音声ファイルを一括で送信したい場合は, `sox wavs/full.wav -e signed -b 16 -c 1 -r 16000 -t raw - | nc 0.tcp.jp.ngrok.io 19926` であるが、リアルタイム処理のテストのためには実時間と同期させなければならない。

`pv`（Pipe Viewer）コマンドを用いることでデータの流れを1秒あたりの実際のバイト数に制限する. 
`-L 32000` オプションにより、 16ビット（2バイト）(`-b 16`) サンプルの16000Hz (`-r 16000`) の音声を処理するので、1秒あたり32000バイトの速度でデータを制限することで。データの送信速度がリアルタイムの録音速度に一致するようになる。

# Reference
* https://qiita.com/t_katsumura/items/a83431671a41d9b6358f#3-python%E3%81%AB%E3%82%88%E3%82%8B%E3%82%BD%E3%82%B1%E3%83%83%E3%83%88%E9%80%9A%E4%BF%A1

* https://zenn.dev/momosuke/articles/whisper-streaming
* https://github.com/ufal/whisper_streaming
* https://github.com/SYSTRAN/faster-whisper
* https://blog.recruit.co.jp/rmp/infrastructure/auto_video_editing_with_ffmpeg/
* https://knowledge.sakura.ad.jp/34497/#Web