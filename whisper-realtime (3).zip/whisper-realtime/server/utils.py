import re

UNNECESSARY_TEXTS = [
    "ご視聴ありがとうございました",
    "チャンネル登録をお願いいたします",
    "ありがとうございました",
]
# 正規表現で使うための末尾のパターン
PATTERN = r"[、。．，！？.,!?\'\"\s\u3000\n\t]"
PATTERN_PERIOD = r"[。．！？.!?\n\t]"
PATTERN_COMMA = r"[、，,\s\u3000]"


def mch_period(w):
    return bool(re.search(PATTERN_PERIOD, w))


def sub_pattern(text):
    return re.sub(PATTERN, "", text)


def texts_end_start_match(textA: str, textB: str) -> bool:
    """
    Checks if the end of textA matches the beginning of textB dynamically without specifying the match length.

    :param textA: First text string
    :param textB: Second text string
    :return: True if any part of the end of textA matches the beginning of textB, False otherwise
    """
    # Create a pattern from the end of textA, checking for any non-zero length match at the start of textB
    for i in range(len(textA)):
        pattern = re.escape(textA[i:])  # Escape to handle special characters in regex
        if re.match(pattern, textB):
            # return textB[len(textA) - i :]
            return len(textA) - i
    return False
