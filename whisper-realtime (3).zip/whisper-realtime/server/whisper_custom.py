import logging
import os
import sys
from dataclasses import dataclass

import numpy as np
import reazonspeech.nemo.asr as nemo_asr
import torch
from faster_whisper import WhisperModel
from nemo.collections.asr.models import EncDecRNNTBPEModel as ReazonModel
from utils import UNNECESSARY_TEXTS, mch_period, sub_pattern

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


from common import SAMPLING_RATE, ASRResult, suppress_output


@dataclass
class TranscribeConfig:
    verbose: bool = True
    raw_hypothesis: bool = False


class FasterWhisperASR:
    """Uses faster-whisper library as the backend. Works much faster, appx 4-times (in offline mode). For GPU, it requires installation with a specific CUDNN version."""

    def __init__(self, lan, modelsize=None, cache_dir=None, vad_filter: bool = False):
        self.transcribe_kargs = {
            "language": lan if lan != "auto" else None,
            "vad_filter": vad_filter,
            "beam_size": 3,
            "word_timestamps": False,
            "condition_on_previous_text": True,
            "log_prob_threshold": -0.45,
        }
        self.model: WhisperModel = self.load_model(modelsize, cache_dir)

        self._print_log()

    def _print_log(self):
        print("-" * 80)
        for k, v in self.transcribe_kargs.items():
            print(f"{k}:\t{v}")
        print("-" * 80)

    def load_model(self, modelsize=None, cache_dir=None) -> WhisperModel:
        model = WhisperModel(
            modelsize,
            device="cuda",  # or "cpu"
            compute_type="float16",  # or "int8_float16" or "int8"
            download_root=cache_dir,
        )

        return model

    @suppress_output
    def transcribe(self, audio, initial_prompt=""):
        # tested: beam_size=5 is faster and better than 1 (on one 200 second document from En ESIC, min chunk 0.01)
        # info contains language detection result
        segments, info = self.model.transcribe(
            audio,
            initial_prompt=initial_prompt,
            **self.transcribe_kargs,
        )
        return list(segments)


class OnlineASRProcessor:
    def __init__(self, asr_model: str, whisper_model_size: str = "large-v3"):
        """asr: WhisperASR object"""

        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        assert asr_model in ["whisper", "reazon"]
        self.asr_model = asr_model

        if self.asr_model == "whisper":
            whisper_load_kwargs = {
                "modelsize": whisper_model_size,
                "lan": "ja",
                "cache_dir": None,
            }
            logging.info(f"Loading Whisper {whisper_load_kwargs['modelsize']} model for {whisper_load_kwargs['lan']}...")
            self.asr: FasterWhisperASR = FasterWhisperASR(**whisper_load_kwargs)
        elif self.asr_model == "reazon":
            self.asr: ReazonModel = nemo_asr.load_model()
            self.config = TranscribeConfig(verbose=False)

    def process_iter(self, audio: np.ndarray, initial_prompt: str = "") -> list[ASRResult]:
        """Runs on the current audio buffer."""
        result_setences: list[ASRResult]

        if self.asr_model == "whisper":
            self.asr: FasterWhisperASR
            res = self.asr.transcribe(audio, initial_prompt)
            segments = [r for r in res if sub_pattern(r.text) not in UNNECESSARY_TEXTS and r.avg_logprob > -0.45]
            result_setences = [ASRResult(seg.start, seg.end, seg.text) for seg in segments]
        elif self.asr_model == "reazon":
            audio_data = nemo_asr.audio_from_numpy(audio, SAMPLING_RATE)
            ret = nemo_asr.transcribe(self.asr, audio_data, self.config)
            result_setences = [ASRResult(r.start_seconds, r.end_seconds, r.text) for r in ret.segments]

        if len(result_setences) > 0:
            print("-" * 10)
            logging.info(len(result_setences))
            for r in result_setences:
                logging.info(r.text)

        return result_setences
