import argparse
import io
import logging
import os
import shutil
import socket
from abc import ABC, abstractmethod

import librosa
import numpy as np
import soundfile
from faster_whisper.vad import get_speech_timestamps
from whisper_custom import OnlineASRProcessor

from common import SAMPLING_RATE, ASRResult


class ConnectionBase(ABC):
    def __init__(self, timeout: int = 60, buffer: int = 65536):
        self.__socket: socket.socket = None
        self.__timeout = timeout
        self.__buffer = buffer
        self.__conn: socket.socket = None
        self.close()

    def __del__(self):
        self.close()

    def close(self) -> None:
        try:
            self.__socket.shutdown(socket.SHUT_RDWR)
            self.__socket.close()
        except Exception:
            pass

    def run(self, host, port: int) -> None:
        """socket() → bind() → listen() → accept() → receive()/send() → close()"""
        self.__socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.__socket.settimeout(self.__timeout)
        self.__socket.bind((host, port))
        self.__socket.listen(1)
        logging.info("INFO: Listening on" + str((host, port)))

        while True:
            self.__conn, addr = self.__socket.accept()
            try:
                self.process()
            except ConnectionResetError:
                break
            except BrokenPipeError:
                break
        logging.info("INFO: Connection closed, terminating.")
        self.close()

    def send(self, response: str) -> None:
        self.__conn.send(response.encode("utf-8"))

    def non_blocking_receive_audio(self):
        r = self.__conn.recv(self.__buffer)
        return r

    @abstractmethod
    def process(self):
        raise NotImplementedError


class ServerProcessor(ConnectionBase):
    def __init__(
        self,
        online_asr_proc: OnlineASRProcessor,
        min_chunk,
        max_duration_thr: float = 5.0,
        timeout: int = 60,
        buffer: int = 1024,
        debug: bool = False,
    ):
        """
        Args:
            max_duration_thr: 繋ぎの音成長がこの秒数を超えたら, 途中でも音声を送信する.
        """
        super().__init__(timeout, buffer)
        self.online_asr_proc = online_asr_proc
        self.min_chunk = min_chunk
        self.max_duration_thr = max_duration_thr
        self.debug = debug

    def receive_audio_chunk(self) -> np.ndarray:
        # receive all audio that is available by this time
        # blocks operation if less than self.min_chunk seconds is available
        # unblocks if connection is closed or a chunk is available
        out = []
        while sum(len(x) for x in out) < self.min_chunk * SAMPLING_RATE:
            raw_bytes = self.non_blocking_receive_audio()
            if not raw_bytes:
                break
            sf = soundfile.SoundFile(
                io.BytesIO(raw_bytes),
                channels=1,
                endian="LITTLE",
                samplerate=SAMPLING_RATE,
                subtype="PCM_16",
                format="RAW",
            )
            audio, _ = librosa.load(sf, sr=SAMPLING_RATE)
            out.append(audio)
        if not out:
            return None
        return np.concatenate(out)

    def process(self):
        """音声を受信して文字起こしを行い, 結果を送信する.
        音声にある程度の長さを持たせないと認識性能が悪いので、文字起こし結果はすぐに送信せずにbufferに溜めておき、
        明らかに文が分かれた場合や音声が途切れた場合に送信する.
        """
        # handle one client connection
        silent_duration = 0.0
        audio_buffer = np.array([], dtype=np.float32)
        result_buffer: list[ASRResult] = []

        count = 0
        SILENT_SEC = 1
        silent_audio = np.zeros(int(SAMPLING_RATE * SILENT_SEC))

        last_sent_text: str = ""

        while True:
            send_results = []
            audio_chunk = self.receive_audio_chunk()

            # VAD
            speeches = get_speech_timestamps(audio_chunk)

            # 次の場合に音声を追加して文字起こしする
            # 空白->人声あり, 人声あり->人声あり, 人声あり->空白 (音声の連続性を保つため)
            is_speech = len(speeches) != 0
            if is_speech:
                audio_buffer = np.append(audio_buffer, audio_chunk)
                input_audio = np.concatenate([silent_audio, audio_buffer, silent_audio])
                result_buffer = self.online_asr_proc.process_iter(input_audio, last_sent_text)
                silent_duration = 0.0
            else:
                silent_duration += len(audio_chunk) / SAMPLING_RATE

            # 明確に2文以上に分かれている場合や, 音声が途切れた場合に文字起こしを送信する.
            is_multi_sentneces = len(result_buffer) > 1
            is_end_speech = silent_duration > 0.5 and len(result_buffer) > 0
            exceed_max_duration = len(audio_buffer) / SAMPLING_RATE > self.max_duration_thr

            if is_multi_sentneces or is_end_speech or exceed_max_duration:
                logging.info(f"{is_multi_sentneces}, {is_end_speech}, {exceed_max_duration}")

                if self.debug:
                    np.save(f"test/audio_buffer_{count}.npy", audio_buffer)
                    count += 1

                if is_multi_sentneces:
                    send_results = result_buffer[:-1]
                    # 送信した部分を削除
                    end = send_results[-1].end - SILENT_SEC
                    audio_buffer = audio_buffer[round(end * SAMPLING_RATE) :]
                else:
                    send_results = result_buffer
                    # 全て送信したのでbufferを空にする
                    audio_buffer = np.array([], dtype=np.float32)

                if send_results:
                    json_result = [r.to_json() for r in send_results]
                    msg = str(json_result)
                    self.send(msg)
                    result_buffer = []
                    logging.info(f'>>> Sent: "{msg}"')
            last_sent_text = "".join([r.text for r in send_results])


if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    # server options
    parser.add_argument("--host", type=str, default="localhost")
    parser.add_argument("--port", type=int, default=1935)
    # transcribing model options
    parser.add_argument(
        "--asr_model",
        type=str,
        default="whisper",
        # default="reazon",
        choices=["whisper", "reazon"],
        help="ASR model to use",
    )
    parser.add_argument(
        "--whisper_model_size",
        type=str,
        default="large-v3",
        choices="tiny.en tiny base.en base small.en small medium.en medium large-v1 large-v2 large-v3 large",
        help="Name size of the Whisper model to use (default: large-v2). The model is automatically downloaded from the model hub if not present in model cache dir.",
    )
    parser.add_argument(
        "--min_chunk_size",
        type=float,
        default=1.0,
        help="Minimum audio chunk size in seconds. It waits up to this time to do processing. If the processing takes shorter time, it waits, otherwise it processes the whole segment that was received by this time.",
    )
    parser.add_argument(
        "--max_duration_thr",
        type=float,
        default=5.0,
        help="If the duration of the audio segment exceeds this value, the partial transcript is sent immediately.",
    )
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()

    # logging
    logging.basicConfig(
        level=logging.INFO,
        format="[%(asctime)s] [%(filename)s:%(lineno)d] [%(levelname)s]: %(message)s",
        datefmt="%Y/%m/%d %H:%M:%S",
    )

    # ----------------------------------
    if args.debug:
        shutil.rmtree("test", ignore_errors=True)
        os.makedirs("test", exist_ok=True)
    # ----------------------------------

    online = OnlineASRProcessor(args.asr_model, args.whisper_model_size)

    connection = ServerProcessor(online, args.min_chunk_size, debug=args.debug)
    connection.run(args.host, args.port)
