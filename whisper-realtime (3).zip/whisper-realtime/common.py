import os
from dataclasses import asdict, dataclass, fields
from functools import wraps

import pyaudio
from pydantic import BaseModel

FORMAT = pyaudio.paInt16  # 16ビットフォーマット
CHANNELS = 1
SAMPLING_RATE = 16000
BIT_RATE = "16k"
CHUNK_SIZE = 4096  # バッファサイズ

SAMPLING_RATE = 16000
DIGIT = 2


# class MyBaseModel(BaseModel):
class MyBaseModel:
    def __init__(self, *args, **data):
        if args and not data:
            child_class = type(self)
            data = {k.name: v for k, v in zip(fields(child_class), args)}

        for name, value in data.items():
            value = self._clip_value(name, value)
            value = self._round_all(value)
            data[name] = value
        # super().__init__(**data)

    def __setattr__(self, name, value):
        value = self._clip_value(name, value)
        value = self._round_all(value)
        super().__setattr__(name, value)

    def _clip_value(self, name, value):
        if name == "start" or name == "end":
            value = max(value, 0.0)
        elif name == "duration":
            value = max(value, 0.01)
        return value

    def _round_all(self, value):
        if isinstance(value, float):
            value = round(value, DIGIT)
        elif isinstance(value, list):
            value = [self._round_all(v) for v in value]
        elif isinstance(value, dict):
            value = {k: self._round_all(v) for k, v in value.items()}
        return value


@dataclass
class ASRResult(MyBaseModel):
    start: float
    end: float
    text: str

    def to_json(self):
        return {
            "start": self.start,
            "end": self.end,
            "text": self.text,
        }


def suppress_output(f):
    """関数による出力を標準出力に表示しない"""

    @wraps(f)
    def wrapper(*args, **kwargs):
        # 標準出力と標準エラー出力を/dev/nullにリダイレクト
        devnull = os.open(os.devnull, os.O_WRONLY)
        old_stdout = os.dup(1)
        old_stderr = os.dup(2)
        os.dup2(devnull, 1)
        os.dup2(devnull, 2)
        os.close(devnull)
        try:
            # 関数の実行
            result = f(*args, **kwargs)
        finally:
            # 標準出力と標準エラー出力を元に戻す
            os.dup2(old_stdout, 1)
            os.dup2(old_stderr, 2)
            os.close(old_stdout)
            os.close(old_stderr)
        return result

    return wrapper
