# ffmpegを使ったやり方
## RTMPサーバー構築 
動画ファイルをストリーミング配信するために、
rtmpサーバをnginxで立て、
ffmpegで配信する。

third-partyのイメージを使ってdockerでnginxのrtmpサーバを立てるのが最も手っ取り早い.
(`tiangolo/nginx-rtmp`)
https://hub.docker.com/r/tiangolo/nginx-rtmp/

```
docker run -d -p 1935:1935 -p 8080:80 tiangolo/nginx-rtmp

ffmpeg -re -i wavs/full.mp4 -c copy -f flv rtmp://localhost/live/stream
```
`-re`: リアルタイム速度で読み込み

OBSで配信しても良いだろうが、obs-websocketを使って実装すると、ややこしいので簡易的にffmpegで実装.

## テキストのリアルタイム重畳
文字起こし結果をテキストファイルに保存する。
先述のコマンドを以下のようにすることで、テキストをオーバーレイすることができる。
```
ffmpeg -re -i wavs/full.mp4 -vf "drawtext=textfile=realtime_subtitles.txt:reload=1:x=100:y=H-th-100:fontsize=64:fontcolor=white:box=1:boxcolor=black@0.5" -c:a copy -f flv rtmp://localhost/live/stream
```
