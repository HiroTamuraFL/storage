import argparse
import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time
import wave

import pyaudio
from pydub import AudioSegment

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import BIT_RATE, CHANNELS, CHUNK_SIZE, FORMAT, SAMPLING_RATE


def listen_for_responses(sock: socket.socket):
    """サーバーからのレスポンスをリスニングする"""
    while True:
        response = sock.recv(CHUNK_SIZE)
        if not response:
            break  # サーバーからのデータがなければ終了
        response_data = json.loads(str(response.decode("utf-8").replace("'", '"')))
        text = "".join([r["text"] for r in response_data])
        print(text)
        with open("realtime_subtitles.txt", "w") as f:
            f.write(text)
            # print(json.dumps(response_data, indent=4, ensure_ascii=False))
            # print("*" * 30)


def send_server_sox(sock: socket.socket, audio_file: str):
    # soxコマンドをsubprocessで実行し、標準出力をパイプで直接読み込む
    sox_command = f"sox {audio_file} -e signed -b 16 -c 1 -r {SAMPLING_RATE} -t raw - | pv -L 32000"
    with subprocess.Popen(sox_command, stdout=subprocess.PIPE, shell=True) as proc:
        while True:
            data = proc.stdout.read(CHUNK_SIZE)
            if not data:
                break
            sock.sendall(data)


def send_server_mic(sock: socket.socket):
    audio = pyaudio.PyAudio()
    stream = audio.open(format=FORMAT, channels=CHANNELS, rate=SAMPLING_RATE, input=True, frames_per_buffer=CHUNK_SIZE)
    try:
        while True:
            data = stream.read(CHUNK_SIZE)
            if not data:
                break
            sock.sendall(data)
    except KeyboardInterrupt:
        print("Streaming stopped")

    stream.stop_stream()
    stream.close()
    audio.terminate()


def send_server_audiofile(sock: socket.socket, audio_file: str):
    audio: AudioSegment
    audio = AudioSegment.from_wav(audio_file)
    audio = audio.set_channels(CHANNELS)
    audio = audio.set_frame_rate(SAMPLING_RATE)

    with tempfile.NamedTemporaryFile(delete=True, suffix=".wav") as temp_file:
        audio.export(temp_file.name, format="wav", bitrate=BIT_RATE)

        with wave.open(temp_file.name, "rb") as wf:
            sample_rate = wf.getframerate()  # サンプルレートを取得
            n_channels = wf.getnchannels()  # チャンネル数を取得
            sampwidth = wf.getsampwidth()  # サンプル幅（バイト数）を取得
            bytes_per_frame = n_channels * sampwidth  # 1フレームあたりのバイト数
            duration_per_chunk = CHUNK_SIZE / sample_rate  # チャンクごとの再生時間（秒）
            try:
                while True:
                    start_time = time.time()
                    data = wf.readframes(CHUNK_SIZE)
                    if not data:
                        break
                    sock.sendall(data)
                    elapsed_time = time.time() - start_time
                    time.sleep(max(0, duration_per_chunk - elapsed_time))  # リアルタイムの再生速度に合わせて待機
            except KeyboardInterrupt:
                print("Streaming stopped")


def broadcast_video(video_file: str, streaming_address: str):
    drawtext = (
        "drawtext=textfile=realtime_subtitles.txt:reload=1:x=10:y=H-th-10:fontsize=64:fontcolor=white:box=1:boxcolor=black@0.5"
    )
    streaming_command = f"ffmpeg -re -i {video_file} -vf {drawtext} -c:a copy -f flv {streaming_address}"
    print(streaming_command)
    subprocess.run(streaming_command, shell=True)


def main(args):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.connect((args.host, args.port))

        listener_thread = threading.Thread(target=listen_for_responses, args=(sock,))
        # broad_cast = threading.Thread(target=broadcast_video, args=(args.video_file, args.streaming_address))
        listener_thread.start()
        # broad_cast.start()

        # send_server_sox(sock)
        if args.source == "file":
            send_server_audiofile(sock, args.audio_file)
        elif args.source == "mic":
            send_server_mic(sock)

        listener_thread.join()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", type=str, default="0.tcp.jp.ngrok.io")
    parser.add_argument("--port", type=int, default=16270)
    parser.add_argument(
        "--source", type=str, default="file", choices=["file", "mic"], help="input source for audio data. file or mic"
    )
    parser.add_argument("--audio_file", type=str, default="wavs/full.wav", help="audio file to send to server")
    parser.add_argument("--video_file", type=str, default="wavs/full.mp4")
    parser.add_argument("--streaming_address", type=str, default="rtmp://localhost/live/stream")
    args = parser.parse_args()

    if args.source == "file":
        assert os.path.exists(args.audio_file), f"File not found: {args.audio_file}"

    main(args)
